package com.crm.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestCrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestCrmApplication.class, args);
	}

}
