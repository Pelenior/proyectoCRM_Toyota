package com.crm.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
